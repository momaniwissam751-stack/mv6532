import 'package:flutter/material.dart';

PageRouteBuilder<T> fadeRoute<T>(Widget page, {Duration duration = const Duration(milliseconds: 250)}) {
  return PageRouteBuilder<T>(
    transitionDuration: duration,
    reverseTransitionDuration: duration,
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, __, child) {
      final curved = CurvedAnimation(parent: animation, curve: Curves.easeOut);
      return FadeTransition(opacity: curved, child: child);
    },
  );
}

PageRouteBuilder<T> slideFadeRoute<T>(Widget page,
    {Duration duration = const Duration(milliseconds: 280), Offset begin = const Offset(0.0, 0.05)}) {
  return PageRouteBuilder<T>(
    transitionDuration: duration,
    reverseTransitionDuration: duration,
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, __, child) {
      final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(position: Tween(begin: begin, end: Offset.zero).animate(curved), child: child),
      );
    },
  );
}
