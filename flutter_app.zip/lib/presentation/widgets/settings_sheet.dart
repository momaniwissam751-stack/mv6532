import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/quiz_provider.dart';

class SettingsSheet extends StatelessWidget {
  const SettingsSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Consumer<QuizProvider>(
          builder: (context, qp, _) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.settings, color: theme.colorScheme.primary),
                  const SizedBox(width: 8),
                  Text('الإعدادات', style: theme.textTheme.titleLarge),
                ],
              ),
              const SizedBox(height: 12),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: Text('تفعيل الأصوات', style: theme.textTheme.titleMedium),
                value: qp.soundEnabled,
                onChanged: (v) {
                  qp.setSoundEnabled(v);
                  qp.persistSettings();
                },
              ),
              const SizedBox(height: 8),
              Text('مدة السؤال (ثوانٍ)', style: theme.textTheme.titleMedium),
              const SizedBox(height: 8),
              Row(
                children: [
                  for (final s in const [10, 15, 20])
                    Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: ChoiceChip(
                        label: Text('$s ث'),
                        selected: qp.secondsPerQuestion == s,
                        onSelected: (_) {
                          qp.setSecondsPerQuestion(s);
                          qp.persistSettings();
                        },
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
