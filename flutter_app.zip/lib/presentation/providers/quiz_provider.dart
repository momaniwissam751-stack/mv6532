import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class QuizQuestion {
  final String question;
  final List<String> options;
  final int correctIndex;
  final String? explanation;
  const QuizQuestion({
    required this.question,
    required this.options,
    required this.correctIndex,
    this.explanation,
  });
}

class QuizProvider extends ChangeNotifier {
  final List<QuizQuestion> _questions = const [
    QuizQuestion(
      question: 'ما المقصود بالاستدامة البيئية؟',
      options: [
        'حماية الموارد الطبيعية وتقليل التلوث للأجيال القادمة',
        'تحقيق الربح فقط',
        'زيادة الاستهلاك لتحسين الاقتصاد',
        'التوسع الحضري بأي تكلفة'
      ],
      correctIndex: 0,
      explanation:
          'الاستدامة البيئية تركز على صون الموارد وتقليل الانبعاثات والتلوث لضمان صحة الكوكب مستقبلًا.',
    ),
    QuizQuestion(
      question: 'أي من التالي يعدّ مثالًا على الطاقة المتجددة؟',
      options: ['الفحم', 'الغاز الطبيعي', 'الرياح', 'النفط'],
      correctIndex: 2,
      explanation:
          'الرياح مصدر متجدد ونظيف للطاقة، بخلاف الوقود الأحفوري مثل الفحم والغاز والنفط.',
    ),
    QuizQuestion(
      question: 'كيف نُخفّض البصمة الكربونية المنزلية؟',
      options: ['زيادة رحلات الطيران', 'إيقاف الأجهزة عند عدم الاستخدام', 'شراء منتجات لمرة واحدة', 'تشغيل المكيف طوال اليوم'],
      correctIndex: 1,
      explanation:
          'إيقاف الأجهزة غير المستخدمة وترشيد الطاقة يحدّان من الانبعاثات المرتبطة بإنتاج الكهرباء.',
    ),
    QuizQuestion(
      question: 'أي سلوك يدعم الاقتصاد الدائري بيئيًا؟',
      options: ['إصلاح الأجهزة القديمة', 'رمي الأشياء سريعًا', 'حرق النفايات منزليًا', 'شراء أكثر من الحاجة'],
      correctIndex: 0,
      explanation:
          'الإصلاح وإطالة العمر والاستخدام المتكرر تقلّل النفايات وتخفّض استهلاك الموارد.',
    ),
    QuizQuestion(
      question: 'أفضل ممارسة للحفاظ على المياه هي:',
      options: ['فتح الصنبور أثناء تنظيف الأسنان', 'الري في الظهيرة', 'إصلاح التسريبات', 'غسل السيارة يوميًا'],
      correctIndex: 2,
      explanation:
          'التسريبات تُهدر كميات كبيرة من المياه؛ إصلاحها يحافظ على هذا المورد البيئي الحيوي.',
    ),
    QuizQuestion(
      question: 'أي خيار نقل أكثر استدامة داخل المدينة؟',
      options: ['المشي أو الدراجة', 'السيارة الخاصة وحدك', 'رحلة جوية قصيرة', 'سيارة قديمة عالية الانبعاثات'],
      correctIndex: 0,
      explanation:
          'المشي والدراجات والنقل العام تخفّض الانبعاثات مقارنة بالسيارات الفردية.',
    ),
    QuizQuestion(
      question: 'لماذا تعدّ حماية التنوع الحيوي مهمة؟',
      options: ['لا تأثير لها', 'تحافظ على توازن النظم البيئية', 'تزيد التلوث', 'تقلل الأمن الغذائي'],
      correctIndex: 1,
      explanation:
          'التنوع الحيوي يدعم استقرار الأنظمة البيئية وخدماتها كالغذاء والماء وتنقية الهواء.',
    ),
    QuizQuestion(
      question: 'اختيار الأغذية المحلية والموسمية يساهم في:',
      options: ['زيادة الانبعاثات', 'تقليل النقل والانبعاثات', 'هدر أكبر', 'تدهور التربة'],
      correctIndex: 1,
      explanation:
          'الأغذية المحلية تحتاج نقلًا أقل، ما يعني انبعاثات أقل وتأثيرًا بيئيًا أخف.',
    ),
    QuizQuestion(
      question: 'ما الإجراء البيئي الأفضل في المنزل؟',
      options: ['استبدال المصابيح بـ LED', 'فتح النوافذ في الشتاء', 'ترك الشاحن موصولًا دائمًا', 'استخدام كيس بلاستيك جديد يوميًا'],
      correctIndex: 0,
      explanation:
          'مصابيح LED تستهلك طاقة أقل وتقلل الانبعاثات المرتبطة بإنتاج الكهرباء.',
    ),
    QuizQuestion(
      question: 'كيف نحدّ من تلوث البلاستيك أحادي الاستخدام؟',
      options: ['استخدام أكياس قابلة لإعادة الاستخدام', 'شراء زجاجات بلاستيكية يوميًا', 'رمي البلاستيك في الطبيعة', 'تجاهل الفرز والتدوير'],
      correctIndex: 0,
      explanation:
          'البدائل القابلة لإعادة الاستخدام والفرز للتدوير تقلّل التلوث وتحمي الحياة البحرية.',
    ),
  ];

  final _player = AudioPlayer();
  static const String applauseAsset = 'assets/audio/applause.mp3';
  static const String wrongAsset = 'assets/audio/wrong.mp3';
  static const String applauseUrl =
      'https://assets.mixkit.co/sfx/preview/mixkit-correct-answer-tone-2870.mp3';
  static const String wrongUrl =
      'https://assets.mixkit.co/sfx/preview/mixkit-wrong-answer-fail-2408.mp3';

  int _currentIndex = 0;
  int _score = 0;
  int _timeLeft = 10; // seconds per question
  bool _answered = false;
  int? _selectedIndex;
  Timer? _timer;

  // Settings / persistence
  bool _soundEnabled = true;
  int _secondsPerQuestion = 10;
  int _bestScore = 0;
  int _attempts = 0;

  QuizProvider() {
    _loadPrefs();
  }

  List<QuizQuestion> get questions => _questions;
  int get currentIndex => _currentIndex;
  int get score => _score;
  int get timeLeft => _timeLeft;
  bool get answered => _answered;
  int? get selectedIndex => _selectedIndex;
  bool get isLastQuestion => _currentIndex == _questions.length - 1;
  bool get soundEnabled => _soundEnabled;
  int get secondsPerQuestion => _secondsPerQuestion;
  int get bestScore => _bestScore;
  int get attempts => _attempts;

  void startQuiz() {
    _currentIndex = 0;
    _score = 0;
    _answered = false;
    _selectedIndex = null;
    _timeLeft = _secondsPerQuestion;
    _startTimer();
    notifyListeners();
  }

  void _startTimer() {
    _timer?.cancel();
    _timeLeft = _secondsPerQuestion;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_timeLeft <= 1) {
        timer.cancel();
        if (!_answered) {
          _answered = true;
          _selectedIndex = null; // no selection
          _timeLeft = 0; // انتهى الوقت
          _playWrong();
          notifyListeners();
        }
      } else {
        _timeLeft -= 1;
        notifyListeners();
      }
    });
  }

  void selectAnswer(int index) {
    if (_answered) return;
    _answered = true;
    _selectedIndex = index;
    final correct = index == _questions[_currentIndex].correctIndex;
    if (correct) {
      _score += 1;
      _playApplause();
      HapticFeedback.mediumImpact();
    } else {
      _playWrong();
      HapticFeedback.lightImpact();
    }
    _timer?.cancel();
    notifyListeners();
  }

  void nextQuestion() {
    if (_currentIndex < _questions.length - 1) {
      _currentIndex += 1;
      _answered = false;
      _selectedIndex = null;
      _startTimer();
      notifyListeners();
    }
  }

  void reset() {
    _timer?.cancel();
    _currentIndex = 0;
    _score = 0;
    _answered = false;
    _selectedIndex = null;
    _timeLeft = _secondsPerQuestion;
    notifyListeners();
  }

  Future<void> _playApplause() async {
    if (!_soundEnabled) return;
    try {
      await _player.play(AssetSource(applauseAsset.replaceFirst('assets/', '')));
    } catch (_) {
      try {
        await _player.play(UrlSource(applauseUrl));
      } catch (_) {}
    }
  }

  Future<void> _playWrong() async {
    if (!_soundEnabled) return;
    try {
      await _player.play(AssetSource(wrongAsset.replaceFirst('assets/', '')));
    } catch (_) {
      try {
        await _player.play(UrlSource(wrongUrl));
      } catch (_) {}
    }
  }

  // Called when user reaches results screen
  Future<void> finishQuiz() async {
    _attempts += 1;
    if (_score > _bestScore) _bestScore = _score;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('bestScore', _bestScore);
      await prefs.setInt('attempts', _attempts);
    } catch (_) {
      // ignore persistence failure silently
    }
    notifyListeners();
  }

  void setSoundEnabled(bool enabled) {
    _soundEnabled = enabled;
    notifyListeners();
  }

  void setSecondsPerQuestion(int seconds) {
    if (seconds < 5 || seconds > 60) return;
    _secondsPerQuestion = seconds;
    // If currently counting down, restart with new value next round
    notifyListeners();
  }

  Future<void> _loadPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final best = prefs.getInt('bestScore');
      final att = prefs.getInt('attempts');
      final sound = prefs.getBool('soundEnabled');
      final secs = prefs.getInt('secondsPerQuestion');

      // Validate and sanitize
      _bestScore = (best != null && best >= 0 && best <= _questions.length) ? best : 0;
      _attempts = (att != null && att >= 0 && att <= 1000000) ? att : 0;
      _soundEnabled = sound ?? true;
      _secondsPerQuestion = (secs != null && secs >= 5 && secs <= 60) ? secs : 10;

      // Auto-sanitize by writing back clean values
      await prefs.setInt('bestScore', _bestScore);
      await prefs.setInt('attempts', _attempts);
      await prefs.setBool('soundEnabled', _soundEnabled);
      await prefs.setInt('secondsPerQuestion', _secondsPerQuestion);
    } catch (_) {
      // On failure keep defaults; do not crash the app
    }
    notifyListeners();
  }

  Future<void> persistSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('soundEnabled', _soundEnabled);
      await prefs.setInt('secondsPerQuestion', _secondsPerQuestion);
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    _player.dispose();
    super.dispose();
  }
}
