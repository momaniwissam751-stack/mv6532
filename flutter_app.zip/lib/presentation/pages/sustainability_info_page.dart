import 'package:flutter/material.dart';

class SustainabilityInfoPage extends StatefulWidget {
  const SustainabilityInfoPage({super.key});

  @override
  State<SustainabilityInfoPage> createState() => _SustainabilityInfoPageState();
}

class _SustainabilityInfoPageState extends State<SustainabilityInfoPage> {
  final _climateKey = GlobalKey();
  final _energyKey = GlobalKey();
  final _waterKey = GlobalKey();
  final _wasteKey = GlobalKey();
  final _biodiversityKey = GlobalKey();
  final _transportKey = GlobalKey();
  final _foodKey = GlobalKey();

  Future<void> _jumpTo(GlobalKey key) async {
    final ctx = key.currentContext;
    if (ctx != null) {
      await Scrollable.ensureVisible(ctx, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text('الاستدامة البيئية 🌿', style: theme.textTheme.titleLarge),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _HeroIntro(),
            const SizedBox(height: 12),
            const SizedBox(height: 12),
            _InfoCard(
              key: _climateKey,
              icon: Icons.thermostat,
              title: 'تغير المناخ',
              body:
                  'ارتفاع درجات الحرارة يتسبب في موجات حر وجفاف وفيضانات. الحلول تشمل تقليل الانبعاثات، الاعتماد على الطاقة المتجددة، وكفاءة الطاقة.',
              actions: const ['توفير الكهرباء', 'استخدام مصابيح LED', 'خفض التكييف/التدفئة'],
            ),
            _InfoCard(
              key: _energyKey,
              icon: Icons.wb_sunny,
              title: 'الطاقة المتجددة',
              body:
                  'الطاقة الشمسية والرياح والمياه مصادر نظيفة تقلل الاعتماد على الوقود الأحفوري وتحد من الانبعاثات.',
              actions: const ['تركيب ألواح شمسية', 'اختيار مزوّد طاقة خضراء', 'استعمال الأجهزة الموفّرة'],
            ),
            _InfoCard(
              key: _waterKey,
              icon: Icons.water_drop,
              title: 'المياه العذبة',
              body: 'ندرة المياه مشكلة عالمية. الترشيد والإصلاح السريع للتسريبات والري الذكي ضرورية.',
              actions: const ['تركيب مرشدات المياه', 'إصلاح التسريبات', 'الري صباحًا/مساءً'],
            ),
            _InfoCard(
              key: _wasteKey,
              icon: Icons.recycling,
              title: 'النفايات والاقتصاد الدائري',
              body:
                  'تقليل وإعادة الاستخدام وإعادة التدوير تقلل الضغط على الموارد والبيئة. الاقتصاد الدائري يطيل عمر المنتجات.',
              actions: const ['الشراء الواعي', 'إصلاح قبل الاستبدال', 'التحويل للتدوير'],
            ),
            _InfoCard(
              key: _biodiversityKey,
              icon: Icons.forest,
              title: 'التنوع الحيوي',
              body: 'حماية النظم البيئية تحافظ على التوازن الطبيعي والأمن الغذائي والمائي.',
              actions: const ['زراعة أشجار محلية', 'دعم المحميات', 'تجنّب المنتجات الضارّة بالغابات'],
            ),
            _InfoCard(
              key: _transportKey,
              icon: Icons.directions_bike,
              title: 'النقل المستدام',
              body: 'المشي والدراجات والنقل العام والسيارات الكهربائية تقلل الانبعاثات والازدحام.',
              actions: const ['المشي/الدراجة للمسافات القصيرة', 'تقاسم الرحلات', 'العمل عن بعد عند الإمكان'],
            ),
            _InfoCard(
              key: _foodKey,
              icon: Icons.restaurant,
              title: 'الغذاء والزراعة',
              body: 'الغذاء المحلي والموسمي وتقليل الهدر يدعم بيئة صحية ويقلل الانبعاثات.',
              actions: const ['وجبات نباتية أكثر', 'تخطيط المشتريات', 'تخزين صحيح لتقليل الهدر'],
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.lightbulb, color: theme.colorScheme.primary),
                        const SizedBox(width: 8),
                        Text('ماذا يمكننا أن نفعل للبيئة؟', style: theme.textTheme.titleLarge),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'ابدأ بخطوات عملية تحمي البيئة: وفّر الطاقة والماء، اختر منتجات صديقة للبيئة، قلّل استهلاك البلاستيك، استخدم النقل المستدام، وازرع شجرة إن استطعت. الأفعال الصغيرة تغيّر الكثير! 🌱',
                      style: theme.textTheme.bodyLarge,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _HeroIntro extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.colorScheme.primary, theme.colorScheme.secondary],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('معلومات عن الاستدامة البيئية',
                    style: theme.textTheme.titleLarge!.copyWith(color: theme.colorScheme.onPrimary)),
                const SizedBox(height: 6),
                Text(
                  'تعرف على أهم القضايا البيئية والحلول العملية التي يمكنك تطبيقها يوميًا.',
                  style: theme.textTheme.bodyMedium!.copyWith(color: theme.colorScheme.onPrimary),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Icon(Icons.eco, color: theme.colorScheme.onPrimary, size: 32),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final List<String> actions;
  const _InfoCard({super.key, required this.icon, required this.title, required this.body, required this.actions});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Expanded(child: Text(title, style: theme.textTheme.titleLarge)),
              ],
            ),
            const SizedBox(height: 8),
            Text(body, style: theme.textTheme.bodyLarge),
          ],
        ),
      ),
    );
  }
}
