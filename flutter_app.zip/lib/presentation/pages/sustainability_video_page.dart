import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import '../pages/sustainability_quiz_page.dart';
import 'sustainability_info_page.dart';
import '../providers/quiz_provider.dart';
import '../widgets/settings_sheet.dart';
import '../navigation/routes.dart';

class SustainabilityVideoPage extends StatefulWidget {
  const SustainabilityVideoPage({super.key});

  @override
  State<SustainabilityVideoPage> createState() => _SustainabilityVideoPageState();
}

class _SustainabilityVideoPageState extends State<SustainabilityVideoPage> {
  // YouTube video: https://youtu.be/59jW_OkunUA
  static const String _youtubeVideoId = '59jW_OkunUA';
  late final YoutubePlayerController _ytController;
  bool _videoCompleted = false;

  @override
  void initState() {
    super.initState();
    _ytController = YoutubePlayerController.fromVideoId(
      videoId: _youtubeVideoId,
      autoPlay: false,
      params: const YoutubePlayerParams(
        showFullscreenButton: true,
        enableCaption: true,
        strictRelatedVideos: true,
        playsInline: true,
        loop: false,
      ),
    )..listen((event) {
        if (event.playerState == PlayerState.ended && mounted) {
          setState(() => _videoCompleted = true);
        }
      });
  }

  @override
  void dispose() {
    _ytController.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text('تعلم الاستدامة البيئية ♻️', style: theme.textTheme.titleLarge),
          actions: [
            IconButton(
              tooltip: 'الإعدادات',
              icon: const Icon(Icons.settings),
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  showDragHandle: true,
                  backgroundColor: Theme.of(context).colorScheme.surface,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                  ),
                  builder: (_) => const SettingsSheet(),
                );
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Hero panel
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Theme.of(context).colorScheme.primary,
                      Theme.of(context).colorScheme.secondary,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('مرحبًا! 👋',
                              style: theme.textTheme.titleLarge!.copyWith(color: Theme.of(context).colorScheme.onPrimary)),
                          const SizedBox(height: 6),
                          Text(
                            'شاهد الفيديو أولاً عن الاستدامة البيئية، ثم ابدأ اختبارًا ممتعًا من 10 أسئلة.',
                            style: theme.textTheme.bodyMedium!.copyWith(color: Theme.of(context).colorScheme.onPrimary),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Icon(Icons.eco, color: Theme.of(context).colorScheme.onPrimary, size: 32),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: YoutubePlayerScaffold(
                    controller: _ytController,
                    aspectRatio: 16 / 9,
                    autoFullScreen: false,
                    builder: (context, player) {
                      return Column(
                        children: [
                          Expanded(child: player),
                        ],
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Consumer<QuizProvider>(
                      builder: (context, qp, _) => ElevatedButton.icon(
                        icon: const Icon(Icons.quiz, color: Colors.white),
                        label: Text('بدء الاختبار',
                            style: theme.textTheme.titleMedium!.copyWith(color: Colors.white)),
                        onPressed: _videoCompleted
                            ? () {
                                qp.startQuiz();
                                Navigator.of(context).push(slideFadeRoute(const SustainabilityQuizPage()));
                              }
                            : null,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: Icon(Icons.public, color: theme.colorScheme.primary),
                      label: Text('صفحة المعلومات', style: theme.textTheme.titleMedium),
                      onPressed: () {
                        Navigator.of(context).push(slideFadeRoute(const SustainabilityInfoPage()));
                      },
                    ),
                  ),
                ],
              ),
              if (!_videoCompleted) ...[
                const SizedBox(height: 8),
                Text(
                  'لا يمكنك الدخول إلى الاختبار قبل مشاهدة الفيديو كاملًا',
                  style: theme.textTheme.labelMedium!.copyWith(color: theme.colorScheme.error),
                  textAlign: TextAlign.center,
                ),
              ] else ...[
                const SizedBox(height: 8),
                Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary.withValues(alpha: 0.12),
                      border: Border.all(color: theme.colorScheme.primary),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle, size: 16, color: theme.colorScheme.primary),
                        const SizedBox(width: 6),
                        Text('تمت مشاهدة الفيديو', style: theme.textTheme.labelMedium),
                      ],
                    ),
                  ),
                )
              ]
            ],
          ),
        ),
      ),
    );
  }

}
