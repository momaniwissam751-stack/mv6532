import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/quiz_provider.dart';
import 'sustainability_quiz_page.dart';
import '../navigation/routes.dart';

class SustainabilityResultPage extends StatelessWidget {
  const SustainabilityResultPage({super.key});

  @override
  Widget build(BuildContext context) {
    final qp = context.watch<QuizProvider>();
    final theme = Theme.of(context);
    final total = qp.questions.length;
    final score = qp.score;
    final best = qp.bestScore;
    final attempts = qp.attempts;
    String badge;
    if (score == total) {
      badge = 'أسطورة الاستدامة البيئية 🏆';
    } else if (score >= (total * 0.8).floor()) {
      badge = 'بطل البيئة 🌟';
    } else if (score >= (total * 0.5).floor()) {
      badge = 'متعلم نشط 💡';
    } else {
      badge = 'واصل التعلّم 📚';
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text('النتيجة النهائية'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('أحسنت! 🎉', style: theme.textTheme.headlineMedium),
                    const SizedBox(height: 12),
                    Text('$score / $total', style: theme.textTheme.displaySmall),
                    const SizedBox(height: 8),
                    Text('استمر في التعلم وممارسة السلوكيات المستدامة يوميًا.',
                        textAlign: TextAlign.center, style: theme.textTheme.bodyLarge),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: theme.colorScheme.primary),
                      ),
                      child: Text(badge, style: theme.textTheme.titleMedium),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _StatChip(icon: Icons.star, label: 'أفضل نتيجة', value: '$best'),
                        const SizedBox(width: 8),
                        _StatChip(icon: Icons.history, label: 'محاولات', value: '$attempts'),
                      ],
                    )
                  ],
                ),
              ),
              ElevatedButton.icon(
                icon: const Icon(Icons.refresh, color: Colors.white),
                label: Text('إعادة المحاولة',
                    style: theme.textTheme.titleMedium!.copyWith(color: Colors.white)),
                onPressed: () {
                  qp.reset();
                  qp.startQuiz();
                  Navigator.of(context).pushReplacement(slideFadeRoute(const SustainabilityQuizPage()));
                },
              ),
              const SizedBox(height: 8),
              Text('نصيحة: شارك أصدقاءك ما تعلمته عن الاستدامة البيئية! 🌿',
                  style: theme.textTheme.labelMedium, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: theme.colorScheme.tertiary,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.colorScheme.outline),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: theme.colorScheme.primary),
          const SizedBox(width: 6),
          Text('$label: ', style: theme.textTheme.labelMedium),
          Text(value, style: theme.textTheme.labelMedium),
        ],
      ),
    );
  }
}
