import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/quiz_provider.dart';
import 'sustainability_result_page.dart';
import '../navigation/routes.dart';

class SustainabilityQuizPage extends StatelessWidget {
  const SustainabilityQuizPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text('اختبار الاستدامة البيئية'),
        ),
        body: const _QuizBody(),
      ),
    );
  }
}

class _QuizBody extends StatefulWidget {
  const _QuizBody();

  @override
  State<_QuizBody> createState() => _QuizBodyState();
}

class _QuizBodyState extends State<_QuizBody> {
  bool _autoScheduled = false;
  int _lastIndex = -1;

  void _maybeAutoAdvance(BuildContext context, QuizProvider qp) {
    // Reset scheduling when moving to a new question
    if (_lastIndex != qp.currentIndex) {
      _autoScheduled = false;
      _lastIndex = qp.currentIndex;
    }

    // Auto-advance only when time ran out (answered with no selection)
    final timeRanOut = qp.answered && qp.selectedIndex == null;
    if (timeRanOut && !_autoScheduled) {
      _autoScheduled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Future.delayed(const Duration(milliseconds: 900), () {
          if (!mounted) return;
          final provider = context.read<QuizProvider>();
          if (provider.isLastQuestion) {
            provider.finishQuiz();
            Navigator.of(context).pushReplacement(slideFadeRoute(const SustainabilityResultPage()));
          } else {
            provider.nextQuestion();
            _autoScheduled = false; // allow scheduling for subsequent timeouts
          }
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final qp = context.watch<QuizProvider>();
    final q = qp.questions[qp.currentIndex];
    final theme = Theme.of(context);
    final progress = qp.timeLeft / qp.secondsPerQuestion;

    _maybeAutoAdvance(context, qp);

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'سؤال ${qp.currentIndex + 1} من ${qp.questions.length}',
                  style: theme.textTheme.titleMedium,
                ),
              ),
              _Countdown(progress: progress, seconds: qp.timeLeft),
            ],
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(q.question, style: theme.textTheme.titleLarge),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.separated(
              itemBuilder: (_, i) {
                final isSelected = qp.selectedIndex == i;
                final isCorrect = q.correctIndex == i;
                final showState = qp.answered;
                Color bg;
                Color border;
                IconData? icon;
                Color? iconColor;
                if (showState && isCorrect) {
                  bg = Theme.of(context).colorScheme.primary.withValues(alpha: 0.12);
                  border = Theme.of(context).colorScheme.primary;
                  icon = Icons.check_circle;
                  iconColor = Colors.green;
                } else if (showState && isSelected && !isCorrect) {
                  bg = Theme.of(context).colorScheme.error.withValues(alpha: 0.10);
                  border = Theme.of(context).colorScheme.error;
                  icon = Icons.cancel;
                  iconColor = Colors.red;
                } else {
                  bg = Theme.of(context).colorScheme.surface;
                  border = Theme.of(context).colorScheme.outline;
                }
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  curve: Curves.easeOut,
                  decoration: BoxDecoration(
                    color: bg,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: border),
                  ),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: qp.answered ? null : () => qp.selectAnswer(i),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                      child: Row(
                        children: [
                          if (icon != null) ...[
                            Icon(icon, color: iconColor, size: 22),
                            const SizedBox(width: 8),
                          ],
                          Expanded(
                            child: Text(
                              q.options[i],
                              style: theme.textTheme.bodyLarge,
                            ),
                          ),
                          Icon(Icons.arrow_back_ios_new, color: Theme.of(context).colorScheme.outline, size: 18),
                        ],
                      ),
                    ),
                  ),
                );
              },
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemCount: q.options.length,
            ),
          ),
          const SizedBox(height: 8),
          _BottomBar(),
        ],
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final qp = context.watch<QuizProvider>();
    final theme = Theme.of(context);
    return Column(
      children: [
        AnimatedOpacity(
          opacity: qp.answered ? 1 : 0,
          duration: const Duration(milliseconds: 200),
          child: qp.answered
              ? Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Text(
                    _feedbackText(context),
                    style: theme.textTheme.titleMedium,
                  ),
                )
              : const SizedBox.shrink(),
        ),
        Row(
          children: [
            if (qp.answered && qp.questions[qp.currentIndex].explanation != null)
              Expanded(
                child: OutlinedButton.icon(
                  icon: Icon(Icons.info, color: theme.colorScheme.primary),
                  label: Text('التفسير', style: theme.textTheme.titleMedium),
                  onPressed: () => _showExplanation(context),
                ),
              ),
            if (qp.answered && qp.questions[qp.currentIndex].explanation != null)
              const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton.icon(
                icon: Icon(
                  qp.isLastQuestion ? Icons.flag : Icons.arrow_forward,
                  color: Colors.white,
                ),
                label: Text(qp.isLastQuestion ? 'النتيجة' : 'السؤال التالي',
                    style: theme.textTheme.titleMedium!.copyWith(color: Colors.white)),
                onPressed: !qp.answered
                    ? null
                    : () {
                        if (qp.isLastQuestion) {
                          qp.finishQuiz();
                          Navigator.of(context).pushReplacement(slideFadeRoute(const SustainabilityResultPage()));
                        } else {
                          qp.nextQuestion();
                        }
                      },
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text('النتيجة الحالية: ${qp.score}', style: theme.textTheme.labelMedium),
      ],
    );
  }

  String _feedbackText(BuildContext context) {
    final qp = context.read<QuizProvider>();
    final q = qp.questions[qp.currentIndex];
    final correct = qp.selectedIndex == q.correctIndex;
    if (qp.selectedIndex == null) {
      return 'انتهى الوقت ⏰';
    }
    return correct ? 'إجابة صحيحة! 👏' : 'إجابة خاطئة ❌';
  }

  void _showExplanation(BuildContext context) {
    final qp = context.read<QuizProvider>();
    final q = qp.questions[qp.currentIndex];
    final theme = Theme.of(context);
    final text = q.explanation ?? '';
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.info, color: theme.colorScheme.primary),
                const SizedBox(width: 8),
                Text('التفسير', style: theme.textTheme.titleLarge),
              ],
            ),
            const SizedBox(height: 12),
            Text(text, style: theme.textTheme.bodyLarge),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _Countdown extends StatelessWidget {
  const _Countdown({required this.progress, required this.seconds});
  final double progress; // 1..0
  final int seconds;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      width: 64,
      height: 64,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: 64,
            height: 64,
            child: CircularProgressIndicator(
              value: progress, // from 1 to 0 visually
              strokeWidth: 6,
              color: theme.colorScheme.primary,
              backgroundColor: theme.colorScheme.secondary.withValues(alpha: 0.2),
            ),
          ),
          Text('$seconds', style: theme.textTheme.titleMedium),
        ],
      ),
    );
  }
}
