import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

///  Theme Implementation
///
/// This file contains a complete simple theme implementation that exactly
/// matches the color tokens and mappings from the original .dart theme pack.
///
/// Key features:
/// - Exact color values from the original  theme (both light and dark modes)
/// - Proper mapping to Material Design 3 color scheme
/// - Clean monochromatic aesthetic with black/white primary colors
/// - 8px border radius and consistent spacing
/// - Inter font family (closest alternative to Geist)
///
/// This implementation is self-contained and doesn't require the template_themes package.

/// Light mode colors – modern eco palette
class LightColors {
  static const background = Color(0xFFF7FAF7);
  static const foreground = Color(0xFF041B14);
  static const card = Color(0xFFFFFFFF);
  static const cardForeground = foreground;
  static const popover = Color(0xFFF0F7F3);
  static const popoverForeground = foreground;
  static const primary = Color(0xFF10B981); // emerald
  static const primaryForeground = Color(0xFFFFFFFF);
  static const secondary = Color(0xFF0EA5E9); // sky blue
  static const secondaryForeground = Color(0xFFFFFFFF);
  static const muted = Color(0xFFE8F2EC);
  static const mutedForeground = Color(0xFF35524B);
  static const accent = Color(0xFF84CC16); // lime
  static const accentForeground = Color(0xFF0F1F11);
  static const destructive = Color(0xFFEF4444);
  static const destructiveForeground = Color(0xFFFFFFFF);
  static const border = Color(0xFFD6E6DD);
  static const input = Color(0xFFF1F6F3);
  static const ring = primary;

  // Charts / extras
  static const chart1 = Color(0xFF10B981);
  static const chart2 = Color(0xFF0EA5E9);
  static const chart3 = Color(0xFF84CC16);
  static const chart4 = Color(0xFF22D3EE);
  static const chart5 = Color(0xFF64748B);
}

/// Dark mode colors – deep eco palette
class DarkColors {
  static const background = Color(0xFF0A0F0D);
  static const foreground = Color(0xFFE5F5EC);
  static const card = Color(0xFF0F1513);
  static const cardForeground = foreground;
  static const popover = Color(0xFF111A16);
  static const popoverForeground = foreground;
  static const primary = Color(0xFF34D399);
  static const primaryForeground = Color(0xFF032319);
  static const secondary = Color(0xFF38BDF8);
  static const secondaryForeground = Color(0xFF062033);
  static const muted = Color(0xFF15201B);
  static const mutedForeground = Color(0xFFAAD7C7);
  static const accent = Color(0xFFA3E635);
  static const accentForeground = Color(0xFF0A140B);
  static const destructive = Color(0xFFF87171);
  static const destructiveForeground = Color(0xFF220505);
  static const border = Color(0xFF1E2A25);
  static const input = Color(0xFF141C19);
  static const ring = primary;

  // Additional
  static const chart1 = Color(0xFF34D399);
  static const chart2 = Color(0xFF38BDF8);
  static const chart3 = Color(0xFFA3E635);
  static const chart4 = Color(0xFF22D3EE);
  static const chart5 = Color(0xFF94A3B8);
  static const sidebar = Color(0xFF0E1412);
}

/// Font sizes following Material Design 3 guidelines
class FontSizes {
  static const double displayLarge = 57.0;
  static const double displayMedium = 45.0;
  static const double displaySmall = 36.0;
  static const double headlineLarge = 32.0;
  static const double headlineMedium = 24.0;
  static const double headlineSmall = 22.0;
  static const double titleLarge = 22.0;
  static const double titleMedium = 18.0;
  static const double titleSmall = 16.0;
  static const double labelLarge = 16.0;
  static const double labelMedium = 14.0;
  static const double labelSmall = 12.0;
  static const double bodyLarge = 16.0;
  static const double bodyMedium = 14.0;
  static const double bodySmall = 12.0;
}

/// Light theme with simple design
ThemeData get lightTheme => ThemeData(
  useMaterial3: true,
  splashFactory: NoSplash.splashFactory,
  colorScheme: ColorScheme.light(
    primary: LightColors.primary,
    onPrimary: LightColors.primaryForeground,
    primaryContainer: LightColors.accent,
    onPrimaryContainer: LightColors.accentForeground,
    secondary: LightColors.secondary,
    onSecondary: LightColors.secondaryForeground,
    tertiary: LightColors.muted,
    onTertiary: LightColors.mutedForeground,
    error: LightColors.destructive,
    onError: LightColors.destructiveForeground,
    errorContainer: LightColors.destructive,
    onErrorContainer: LightColors.destructiveForeground,
    inversePrimary: LightColors.primaryForeground,
    shadow: Colors.black,
    surface: LightColors.background,
    onSurface: LightColors.foreground,
    surfaceContainer: LightColors.card,
    onSurfaceVariant: LightColors.mutedForeground,
    outline: LightColors.border,
  ),
  brightness: Brightness.light,
  scaffoldBackgroundColor: LightColors.background,
  cardColor: LightColors.card,
  dividerColor: LightColors.border,
  appBarTheme: AppBarTheme(
    backgroundColor: LightColors.background,
    foregroundColor: LightColors.foreground,
    elevation: 0,
    surfaceTintColor: Colors.transparent,
  ),
  cardTheme: CardThemeData(
    color: LightColors.card,
    elevation: 0,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
      side: BorderSide(color: LightColors.border, width: 1),
    ),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ButtonStyle(
      backgroundColor: MaterialStatePropertyAll(LightColors.primary),
      foregroundColor: const MaterialStatePropertyAll(LightColors.primaryForeground),
      shape: MaterialStatePropertyAll(
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      padding: const MaterialStatePropertyAll(EdgeInsets.symmetric(horizontal: 20, vertical: 14)),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: LightColors.input,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: LightColors.border),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: LightColors.border),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: LightColors.ring, width: 2),
    ),
  ),
  textTheme: _buildTextTheme(),
);

/// Dark theme with simple design
ThemeData get darkTheme => ThemeData(
  useMaterial3: true,
  splashFactory: NoSplash.splashFactory,
  colorScheme: ColorScheme.dark(
    primary: DarkColors.primary,
    onPrimary: DarkColors.primaryForeground,
    primaryContainer: DarkColors.accent,
    onPrimaryContainer: DarkColors.accentForeground,
    secondary: DarkColors.secondary,
    onSecondary: DarkColors.secondaryForeground,
    tertiary: DarkColors.muted,
    onTertiary: DarkColors.mutedForeground,
    error: DarkColors.destructive,
    onError: DarkColors.destructiveForeground,
    errorContainer: DarkColors.destructive,
    onErrorContainer: DarkColors.destructiveForeground,
    inversePrimary: DarkColors.primaryForeground,
    shadow: Colors.black,
    surface: DarkColors.background,
    onSurface: DarkColors.foreground,
    surfaceContainer: DarkColors.card,
    onSurfaceVariant: DarkColors.mutedForeground,
    outline: DarkColors.border,
  ),
  brightness: Brightness.dark,
  scaffoldBackgroundColor: DarkColors.background,
  cardColor: DarkColors.card,
  dividerColor: DarkColors.border,
  appBarTheme: AppBarTheme(
    backgroundColor: DarkColors.background,
    foregroundColor: DarkColors.foreground,
    elevation: 0,
    surfaceTintColor: Colors.transparent,
  ),
  cardTheme: CardThemeData(
    color: DarkColors.card,
    elevation: 0,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
      side: BorderSide(color: DarkColors.border, width: 1),
    ),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ButtonStyle(
      backgroundColor: MaterialStatePropertyAll(DarkColors.primary),
      foregroundColor: const MaterialStatePropertyAll(DarkColors.primaryForeground),
      shape: MaterialStatePropertyAll(
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      padding: const MaterialStatePropertyAll(EdgeInsets.symmetric(horizontal: 20, vertical: 14)),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: DarkColors.input,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: DarkColors.border),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: DarkColors.border),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: DarkColors.ring, width: 2),
    ),
  ),
  textTheme: _buildTextTheme(),
);

/// Helper function to build consistent text theme
/// Arabic-first typography using Cairo for excellent legibility
TextTheme _buildTextTheme() {
  return TextTheme(
    displayLarge: GoogleFonts.cairo(
      fontSize: FontSizes.displayLarge,
      fontWeight: FontWeight.w700,
    ),
    displayMedium: GoogleFonts.cairo(
      fontSize: FontSizes.displayMedium,
      fontWeight: FontWeight.w700,
    ),
    displaySmall: GoogleFonts.cairo(
      fontSize: FontSizes.displaySmall,
      fontWeight: FontWeight.w600,
    ),
    headlineLarge: GoogleFonts.cairo(
      fontSize: FontSizes.headlineLarge,
      fontWeight: FontWeight.w600,
    ),
    headlineMedium: GoogleFonts.cairo(
      fontSize: FontSizes.headlineMedium,
      fontWeight: FontWeight.w600,
    ),
    headlineSmall: GoogleFonts.cairo(
      fontSize: FontSizes.headlineSmall,
      fontWeight: FontWeight.w700,
    ),
    titleLarge: GoogleFonts.cairo(
      fontSize: FontSizes.titleLarge,
      fontWeight: FontWeight.w600,
    ),
    titleMedium: GoogleFonts.cairo(
      fontSize: FontSizes.titleMedium,
      fontWeight: FontWeight.w600,
    ),
    titleSmall: GoogleFonts.cairo(
      fontSize: FontSizes.titleSmall,
      fontWeight: FontWeight.w600,
    ),
    labelLarge: GoogleFonts.cairo(
      fontSize: FontSizes.labelLarge,
      fontWeight: FontWeight.w600,
    ),
    labelMedium: GoogleFonts.cairo(
      fontSize: FontSizes.labelMedium,
      fontWeight: FontWeight.w600,
    ),
    labelSmall: GoogleFonts.cairo(
      fontSize: FontSizes.labelSmall,
      fontWeight: FontWeight.w600,
    ),
    bodyLarge: GoogleFonts.cairo(
      fontSize: FontSizes.bodyLarge,
      fontWeight: FontWeight.w500,
      height: 1.5,
    ),
    bodyMedium: GoogleFonts.cairo(
      fontSize: FontSizes.bodyMedium,
      fontWeight: FontWeight.w500,
      height: 1.5,
    ),
    bodySmall: GoogleFonts.cairo(
      fontSize: FontSizes.bodySmall,
      fontWeight: FontWeight.w500,
      height: 1.5,
    ),
  );
}
